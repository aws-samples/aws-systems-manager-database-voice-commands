set echo off
set head off
SELECT
        'Tablespace ' || df.tablespace_name || ': ' ||
        round(100 * ( (df.totalspace - (df.totalspace - tu.totalusedspace))/ df.totalspace)) || ' percent used. ' result
FROM
	(select tablespace_name, round(sum(bytes) / 1048576) TotalSpace
	from dba_data_files
	group by tablespace_name) df,
	(select round(sum(bytes)/(1024*1024)) totalusedspace, tablespace_name
	from dba_segments
	group by tablespace_name) tu
WHERE df.tablespace_name = tu.tablespace_name
AND round(100 * ( (df.totalspace - (df.totalspace - tu.totalusedspace))/ df.totalspace)) > 90 
AND ROWNUM<21;
exit;
