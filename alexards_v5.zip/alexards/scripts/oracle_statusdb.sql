set echo off
SELECT DECODE(open_mode,'READ WRITE','CONNECTED') FROM v$database;
exit;

