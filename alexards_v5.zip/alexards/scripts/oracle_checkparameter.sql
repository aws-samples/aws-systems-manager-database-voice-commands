set echo off
set head off
set verify off

SELECT value FROM v$parameter WHERE name = '&1';

exit;

