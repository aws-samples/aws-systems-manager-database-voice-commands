set echo off
set head off
SELECT 'Session ID: ' || tb.sid || ', Username: ' || tb.username
FROM  
 (
  SELECT ss.sid as sid, se.username as username 
FROM v$session se, v$sesstat ss, v$statname st
WHERE ss.statistic# = st.statistic#
AND st.name LIKE '%CPU used by this session%'
AND se.sid = ss.sid
AND se.username IS NOT NULL 
ORDER BY value DESC ) tb
WHERE ROWNUM < 2;
exit;